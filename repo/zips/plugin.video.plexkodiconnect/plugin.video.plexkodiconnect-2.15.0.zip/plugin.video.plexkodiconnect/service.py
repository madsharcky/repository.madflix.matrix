# -*- coding: utf-8 -*-
###############################################################################
from __future__ import absolute_import, division, unicode_literals
from resources.lib import service_entry


if __name__ == "__main__":
    service_entry.start()
