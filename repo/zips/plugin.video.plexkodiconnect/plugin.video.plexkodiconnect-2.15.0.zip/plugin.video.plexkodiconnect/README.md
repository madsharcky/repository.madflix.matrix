Hello There
This is a readme

All the Visuals are located in 
C:\Users\mad_s\AppData\Roaming\Kodi\addons\plugin.video.plexkodiconnect\resources\skins\Main\media\plugin.video.plexkodiconnect